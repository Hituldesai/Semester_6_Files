#!/usr/bin/env python

import rospy
from std_msgs.msg import String
name = "txt"
roll = "num"

def callback(data):
    global name
    global roll
    try:
        float(data.data[0])
        roll = data.data
    except ValueError:
        name = data.data
    rospy.loginfo('%s_%s', name, roll)

def listener():
    rospy.init_node('listener', anonymous=True)
    rospy.Subscriber('callback', String, callback)
    rospy.spin()

if __name__ == '__main__':
    listener()
