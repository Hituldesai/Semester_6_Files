#!/usr/bin/env python

import rospy
from std_msgs.msg import String

def talker():
    pub2 = rospy.Publisher('callback', String, queue_size=10)
    rospy.init_node('talker2', anonymous=True)
    rate = rospy.Rate(10) # 10hz
    while not rospy.is_shutdown():
        str = "16D170028"
        rospy.loginfo(str)
        pub2.publish(str)
        rate.sleep()

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass
