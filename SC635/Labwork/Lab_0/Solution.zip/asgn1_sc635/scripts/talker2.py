#!/usr/bin/env python
import sys
import rospy
from std_msgs.msg import String

def talker(student_data, topic_type):
    # Publish to chatter 
    pub = rospy.Publisher('{}'.format(topic_type), String, queue_size=10)

    # Initialize the talker2 node
    rospy.init_node('talker2', anonymous=True)

    rate = rospy.Rate(10)
    while not rospy.is_shutdown():
        mssg2pub = "{}".format(student_data) 
        pub.publish(mssg2pub)
        rate.sleep()

if __name__ == '__main__':
    try:
        talker(sys.argv[1], sys.argv[2])
    except rospy.ROSInterruptException:
        pass