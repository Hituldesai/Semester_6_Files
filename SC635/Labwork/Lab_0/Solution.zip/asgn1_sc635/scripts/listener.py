#!/usr/bin/env python
import sys
import rospy
from std_msgs.msg import String

global recieved_name, recieved_roll
recieved_name = "none"
recieved_roll = "1234"

def name_cb(data):
	global recieved_name
	recieved_name = data.data

def roll_cb(data):
	global recieved_roll
	recieved_roll = data.data

def listener(all_topics):
	# Initialize the listener node
    rospy.init_node('listener', anonymous=True)

	# Subscribes from all topics
    rospy.Subscriber('{}'.format(all_topics[0]), String, name_cb)
    rospy.Subscriber('{}'.format(all_topics[1]), String, roll_cb)

    rate = rospy.Rate(10)
    while not rospy.is_shutdown():
        # Display
        print "Student {} has roll number: {}".format(recieved_name,recieved_roll)
        rate.sleep()

    rospy.spin()

if __name__ == '__main__':
    try:
        listener(sys.argv[1:])
    except rospy.ROSInterruptException:
        pass